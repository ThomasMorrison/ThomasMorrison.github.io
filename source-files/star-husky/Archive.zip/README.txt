README

If you want to look at the underlying files of the .c3p file simply change the exepension to .zip and decompress it.

Leave the file as a .c3p to open it in Construct 3
